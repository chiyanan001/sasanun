<?php
include("head.php");
?>
<style>
.register{
  background-color: #fff;
}
</style>
<!------------------------------------------------------Header------------------------------------------------------>

<div class="content-wrapper"> <!-- start1 -->
  <div class="container-fluid"> <!-- start2 -->


    <ol class="breadcrumb">
      <h4>ลงบะเทียนพนักงาน</h4>
    </ol>


    <hr>


    <div class="card mb-3">
      <div class="card-header">
        <ul class="nav nav-pills nav-fill navtop">
          <li class="nav-item">
            <a class="nav-link active" href="#menu1" data-toggle="tab">ส่วนตัว</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#menu2" data-toggle="tab">งาน</a>
          </li>
        </ul>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <div class="tab-content">
            <div class="tab-pane active" role="tabpanel" id="menu1">
              <div class="col-md-6 float-right">
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="1.1">
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="1.2">
                </div>
              </div>
              <div class="col-md-6 float-right">
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="1.1">
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="1.2">
                </div>
              </div>
              <div class="col-md-6 float-right">
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="1.1">
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="1.2">
                </div>
              </div>
            </div> <!-- stop menu1 -->
            <div class="tab-pane" role="tabpanel" id="menu2">
              <div class="col-md-6 float-right">
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="2.1">
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="2.2">
                </div>
              </div>
              <div class="col-md-6 float-right">
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="2.1">
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="2.2">
                </div>
              </div>
              <div class="col-md-6 float-right">
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="2.1">
                </div>
              </div>
              <div class="col-md-6" >
                <div class="form-group">
                  <input type="email" class="form-control" id="" placeholder="2.2">
                </div>
              </div>
            </div>  <!-- stop menu2 -->
          </div>
        </div>
      </div>
    </div>




















  </div>




  <script type="text/javascript" src="../js/register.js"></script>










  <?php
  include("footer.php");
  ?>
