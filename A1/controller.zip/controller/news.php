<?php
include("../model/classNews.php");
$news = new news();
if(isset($_POST['button'])){

  $button = $_POST['button'];

  if($button == "addNews"){
    $news_id = "";
    $date = date("Y/m/d");
    $listNews = $_POST['listNews'];
    $news->addNews($news_id,$listNews,$date);
    echo $news_id,' | ',$listNews,' | ',$date,' | ',$button;
  }  //TheEnd function if

  else if($button == "deleteNews"){
    $delete_id = $_POST['deleteID'];
    $news->deleteNews($delete_id);
    echo $button ," | ",$delete_id;
  }  //TheEnd function else if





}  //TheEnd function if(isset)

else echo "NO";











?>
